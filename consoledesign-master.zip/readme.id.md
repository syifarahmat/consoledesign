# konfigurasi androiddesign
> ini adalah tempat untuk konfigurasi untuk semua proyek android saya

- jangan mengganti struktur folder atau komposisi file di dalamnya
- jika ingin mengambil atau meminta file tambahan, tolong konfirmasi saya
- semua domain dan file bersifat publik tetapi hanya bisa dibaca
- siapa pun dapat melihat isi file tetapi tidak memiliki hak untuk menghapus atau memodifikasinya
- harap dicatat bahwa tidak ada hukum yang dapat menggugat isi dari pada tempat tempat ini karena ini murni inisiatif dari pengembang
