# androiddesign config
> this is store for my config android for all project

 - do not replace the folder structure or the composition of the file
   therein 
 - if want to Take or request additional file please confirm me
 - all domains and files are public but readonly 
 - anyone can see the contents of the file but have no right to delete or modify it
 - please note that no law can sue the contents of this document as it is purely an initiative of the developer
