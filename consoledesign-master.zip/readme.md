# androiddesign config
> this is store for my config android for all project

 - read me [english](https://github.com/syifarahmat/androiddesign/blob/master/readme.en.md)
 - baca [indonesia](https://github.com/syifarahmat/androiddesign/blob/master/readme.id.md)
